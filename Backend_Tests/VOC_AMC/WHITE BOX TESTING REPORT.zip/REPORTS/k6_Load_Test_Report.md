# k6 Load Test Report

## Test Summary

-   **Test Type:** Smoke Load Test
-   **Virtual Users (max):** 10
-   **Duration:** 30 seconds
-   **Target:** Health endpoint (GET)

## Overall Result

  Metric                   Value
  --------------- --------------
  Total Checks               340
  Passed            284 (83.52%)
  Failed             56 (16.47%)
  HTTP Requests              170
  HTTP Failures               0%

### Response Time

  Metric                  Value
  ----------------- -----------
  Average             778.48 ms
  Minimum             520.58 ms
  Median              639.14 ms
  Maximum                1.36 s
  90th Percentile        1.05 s
  95th Percentile        1.14 s

### Validation Results

-   ✅ Status Code 200: Passed for all requests.
-   ⚠️ Response time under 1000 ms: 114 passed, 56 failed (67% success).

### Execution

  Metric                          Value
  ---------------------------- --------
  Iterations                        170
  Average Iteration Duration     1.81 s
  Requests/sec                     5.38

### Network

  Metric            Value
  --------------- -------
  Data Received     80 kB
  Data Sent         24 kB

## Analysis

The application handled all requests successfully without any HTTP
failures, indicating good functional stability under a light load.
However, approximately one-third of the requests exceeded the 1 second
response-time target. The average response time remained below one
second, but the 90th and 95th percentile values crossed the desired
threshold.

## Conclusion

**Result: Partially Passed**

-   Functional reliability: **Pass**
-   Availability: **Pass**
-   Performance target (\<1000 ms): **Needs Improvement**

## Recommendations

1.  Investigate endpoints with response times above 1 second.
2.  Review database queries and API processing time.
3.  Monitor CPU and memory usage during higher loads.
4.  Repeat testing with 25, 50, and 100 virtual users after
    optimization.
