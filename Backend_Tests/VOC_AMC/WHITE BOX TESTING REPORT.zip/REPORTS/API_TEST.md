API Testing - Not Tested Report

Test Case: GET /v1/me (Authenticated User Profile API)

Endpoint:\
GET <https://vocamc-production.up.railway.app/v1/me>

Testing Status:\
NOT TESTED (Blocked due to Authentication Configuration Issue)

Reason for Not Completing Testing:

The API requires a valid Supabase authentication token to access user information.

During testing, a valid Supabase access token was generated and configured in Postman using Bearer Token authentication.

The following checks were completed:

- Authorization header was correctly added:\
  Authorization: Bearer &lt;access_token&gt;

- Postman Console verification confirmed that the Authorization header was successfully sent with the API request.

- JWT token validation checks were performed:

  - Token format: Verified

  - Authorization header transmission: Verified

  - Token expiry: Valid

  - JWT issuer (iss): Matched Supabase project

  - User email: Matched authenticated user

However, the API returned the following response:

{\
"error": {\
"code": "UNAUTHORIZED",\
"message": "Invalid or expired token"\
}\
}

Technical Analysis:

The backend authentication flow uses Supabase token verification.

The request flow is:

Client Request → JwtAuthGuard → SupabaseService.getUser(accessToken) → Supabase Auth Validation → User Details

The failure occurs during Supabase token validation inside the backend:

client.auth.getUser()

The backend is unable to validate the supplied access token.

Reason Testing Could Not Continue:

The backend API is deployed on Railway:

<https://vocamc-production.up.railway.app>

However, access to the Railway deployment environment configuration was not available.

The required Supabase authentication configuration could not be verified:

- SUPABASE_URL

- SUPABASE_ANON_KEY

Additionally, local backend execution could not be performed because the repository did not contain the required environment configuration file (.env).

When attempting to start the backend locally, the following error occurred:

supabaseUrl is required.

Impact:

Authenticated API testing could not be completed because the API requires successful JWT verification before returning user information.

Final Status:

NOT TESTED / BLOCKED

Recommendation:

The deployment administrator should verify the Supabase authentication configuration in the hosted backend environment and redeploy the application if required.

After correcting the authentication configuration, the following API should be tested again:

GET /v1/me

Expected Result:

HTTP 200 OK with authenticated user profile details.