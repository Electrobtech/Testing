| Database Testing Checklist | Status | Evidence |
| --- | --- | --- |
| Insert operations store correct data | **N/A** | Not executed because production database must not be modified. Insert logic exists in services and is unit-tested with mocked Supabase. |
| Update operations modify correct records | **N/A** | Not executed on production. Update logic verified through mocked service tests. |
| Delete operations remove correct records only | **N/A** | Not executed because deleting production data is prohibited. |
| Transactions commit correctly on success | **N/A** | No explicit `BEGIN/COMMIT` transaction blocks are used. Backend relies on Supabase/PostgreSQL operations. |
| Rollback occurs correctly on failure | **N/A** | No explicit transaction implementation exists to verify rollback behavior. |
| Stored procedures return expected results | **N/A** | No stored procedures found. Only trigger functions (`set_updated_at`, `write_audit`) are present. |
| Views return correct joined/filtered data | ✅ PASS | Materialized views are defined: `mv_dealer_revenue`, `mv_dealer_ranking`, `mv_renewal_funnel`, `mv_plan_distribution`. |
| Triggers fire correctly on defined events | ✅ PASS | `trg_audit_*` triggers and `trg_*_updated` triggers are defined for INSERT/UPDATE/DELETE and BEFORE UPDATE events. |
| Constraints enforced (unique, not null, check) | ✅ PASS | Schema contains `NOT NULL`, `UNIQUE`, and `CHECK` constraints (e.g. `price_minor >= 0`, unique phone/reg_no/email). |
| Primary key integrity verified | ✅ PASS | Every table defines a primary key (`id uuid primary key`, composite keys on partitioned tables). |
| Foreign key relationships enforced | ✅ PASS | Extensive `REFERENCES` constraints exist across organizations, dealers, customers, vehicles, memberships, payments, etc. |
| Data consistency across related tables verified | ✅ PASS | Relational integrity is enforced through foreign keys and normalized table relationships. |
| Duplicate record prevention verified | ✅ PASS | Multiple unique constraints prevent duplicates (`membership_no`, `gateway_payment_id`, `(dealer_id, phone)`, `(dealer_id, reg_no)`, `(role_id, module)`, etc.). |
| NULL handling verified across queries and code | ✅ PASS | Nullable vs non-nullable columns are explicitly defined, and your service unit tests already cover null/error scenarios. |
