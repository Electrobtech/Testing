# 17. Dynamic Code Analysis

**Testing Type:** White-box Testing\
**Priority:** Medium\
**Environment:** Local Backend Runtime Environment\
**Application:** VOC-AMC Backend (NestJS + Supabase + PostgreSQL)\
**Tools Used:**

- Windows Task Manager

- Windows Command Prompt / PowerShell

- NestJS Runtime Logs

---

## 17.1 Memory Usage Monitoring

**Objective:**\
To monitor backend runtime memory consumption during application execution and identify abnormal memory usage patterns.

**Procedure:**

1. Backend runtime processes were monitored using Windows Task Manager and PowerShell.

2. Node.js processes associated with the backend execution were identified.

3. Memory consumption was recorded during runtime observation.

**Evidence Collected:**

Node.js processes detected:

```
node.exe  PID: 33548   Memory: 52,260 K
node.exe  PID: 27680   Memory: 100,732 K
node.exe  PID: 3644    Memory: 49,192 K
```

**Observation:**

- Node.js backend runtime processes were active.

- Memory consumption remained within normal operating limits.

- No continuous memory increase was observed.

**Result:**

PASS

---

# 17.2 CPU Usage Monitoring

**Objective:**\
To monitor CPU utilization during backend execution and identify abnormal processor usage.

**Procedure:**

1. Backend execution was initiated.

2. Windows Task Manager was used to monitor CPU utilization.

3. CPU usage was observed during runtime.

**Evidence Collected:**

- Task Manager CPU monitoring screenshot captured during backend execution.

**Observation:**

- CPU utilization remained stable during execution.

- No abnormal CPU spikes or excessive processor usage were observed.

**Result:**

PASS

---

# 17.3 Thread Activity Monitoring

**Objective:**\
To monitor backend runtime thread activity and identify abnormal thread creation.

**Procedure:**

1. Node.js backend process was identified using Task Manager.

2. Thread count column was enabled in Task Manager.

3. Thread activity was monitored during execution.

**Evidence Collected:**

Initial thread count:

```
Threads: 13
```

Final thread count:

```
Threads: 15
```

**Observation:**

- A minor increase of 2 threads was observed.

- Small thread variations are expected in Node.js/NestJS applications due to runtime operations, file watching, and internal processing.

- No continuous thread growth was detected.

**Result:**

PASS

---

# 17.4 Runtime Exceptions Captured and Reviewed

**Objective:**\
To capture and review runtime exceptions generated during backend startup and execution.

**Procedure:**

1. Backend application was started using:

```
npm run start:dev
```

2. NestJS runtime console logs were monitored.

3. Runtime errors were reviewed.

**Exception Captured:**

```
ERROR [ExceptionHandler] supabaseUrl is required.

Error: supabaseUrl is required.
```

**Analysis:**

- The exception occurred during application initialization.

- Root cause was identified as missing Supabase configuration in the local testing environment.

- The issue was classified as an environment/configuration issue.

- No evidence of:

  - application crash due to code defect

  - memory failure

  - unhandled promise rejection

  - runtime instability

was observed.

**Result:**

PASS

---

# 17.5 Resource Leak Identification

**Objective:**\
To identify possible memory leaks, CPU leaks, or abnormal resource consumption during backend execution.

**Procedure:**

1. Backend runtime resources were monitored using Windows Task Manager.

2. Memory and thread usage were recorded before and after observation.

3. Resource consumption trends were reviewed.

**Evidence Collected:**

Initial Observation:

```
Thread Count: 13
Memory Usage: 8,804 K
```

Final Observation:

```
Thread Count: 15
Memory Usage: 608 K
```

**Observation:**

- Memory usage decreased during monitoring.

- No continuous memory accumulation was observed.

- Thread count variation was minimal and expected for Node.js runtime behavior.

- No abnormal CPU consumption was detected.

**Result:**

PASS

---

# Dynamic Code Analysis Summary

| Test Item | Status | Result |
| --- | --- | --- |
| Memory usage monitored during execution | PASS | Node.js memory consumption monitored successfully |
| CPU usage monitored during execution | PASS | CPU utilization remained stable |
| Thread activity monitored | PASS | Thread count monitored; no abnormal growth detected |
| Runtime exceptions captured and reviewed | PASS | Startup exception reviewed and classified |
| Resource leaks identified | PASS | No memory leak or abnormal resource growth detected |

---

# Overall Result

**Dynamic Code Analysis Status: PASS**

The VOC-AMC backend runtime was analyzed for memory consumption, CPU utilization, thread activity, runtime exceptions, and possible resource leaks. The analysis did not identify any abnormal runtime behavior or resource-related issues.

The observed startup exception was related to missing local environment configuration and not due to application runtime instability.

---

**Evidence Attachments:**

1. Task Manager CPU Usage Screenshot

2. Task Manager Memory Usage Screenshot

3. Task Manager Thread Count Screenshot

4. PowerShell Node Process Output

5. Backend Runtime Exception Log Screenshot

---