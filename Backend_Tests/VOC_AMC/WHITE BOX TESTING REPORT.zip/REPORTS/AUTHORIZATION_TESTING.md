## 22. Authorization Testing \[High Priority\] — Complete Report

### Objective

To verify that backend authorization mechanisms correctly restrict access based on:

- User roles

- Assigned permissions

- Authentication status

- Protected API access rules

Testing was performed through static code analysis of the NestJS authorization implementation.

**Testing Restrictions Followed:**

- No application code modified.

- No production database changes performed.

- No unauthorized access attempts executed on live production.

- Authorization logic verified through source-code evidence.

---

# 22.1 Admin-only APIs blocked for non-admin users

## Test Method

Reviewed controller-level role restrictions using:

```powershell
findstr /s /i "Roles" src\*.ts src\**\*.ts
```

## Evidence Found

Location:

```
src/modules/whatsapp/whatsapp.controller.ts
```

Evidence:

```ts
@Roles("super_admin", "corporate_admin", "dealer_admin")

@Post("templates")
@RequirePerm("campaigns:create")
@Roles("super_admin", "dealer_admin")

@Patch("templates/:id")
@RequirePerm("campaigns:edit")
@Roles("super_admin", "dealer_admin")

@Patch("templates/:id/approval")
@RequirePerm("campaigns:edit")
@Roles("super_admin")

@Post("test")
@RequirePerm("campaigns:create")
@Roles("super_admin", "dealer_admin")
```

## Verification

The backend explicitly defines allowed roles for administrative actions.

Examples:

| API Action | Allowed Roles |
| --- | --- |
| Create WhatsApp template | super_admin, dealer_admin |
| Edit template | super_admin, dealer_admin |
| Approve template | super_admin only |
| Test message sending | super_admin, dealer_admin |

Users without required roles are denied access by the authorization layer.

## Status

✅ PASS

---

# 22.2 Role-Based Access Control Enforced in Code

## Test Method

Reviewed authorization guards and role decorators.

Commands used:

```powershell
findstr /s /i "UseGuards" src\*.ts src\**\*.ts
```

and

```powershell
findstr /s /i "Roles" src\*.ts src\**\*.ts
```

## Evidence Found

Example:

```ts
@UseGuards(JwtAuthGuard, RolesGuard, PermissionsGuard)
```

Found in:

```
src/modules/wallet/wallet.controller.ts

src/modules/whatsapp/whatsapp.controller.ts
```

## Authorization Architecture

The request flow is:

```
Incoming Request
        |
        ↓
JwtAuthGuard
        |
        ↓
RolesGuard
        |
        ↓
PermissionsGuard
        |
        ↓
Controller Execution
```

## Verification

The application does not rely on client-side role information.

Roles are validated through backend guards.

## Status

✅ PASS

---

# 22.3 Permission Checks Enforced at Each Protected Action

## Test Method

Reviewed permission decorators.

Command:

```powershell
findstr /s /i "RequirePerm" src\*.ts src\**\*.ts
```

## Evidence Found

Location:

```
src/modules/whatsapp/whatsapp.controller.ts
```

Evidence:

```ts
@Post("templates")
@RequirePerm("campaigns:create")


@Patch("templates/:id")
@RequirePerm("campaigns:edit")


@Patch("templates/:id/approval")
@RequirePerm("campaigns:edit")


@Get("messages")
@RequirePerm("campaigns:view")


@Post("messages/:id/retry")
@RequirePerm("campaigns:edit")


@Post("test")
@RequirePerm("campaigns:create")
```

## Verification

Each sensitive action requires a specific permission.

Permission examples:

| Operation | Required Permission |
| --- | --- |
| Create campaign/template | campaigns:create |
| Modify campaign/template | campaigns:edit |
| View messages | campaigns:view |

## Status

✅ PASS

---

# 22.4 Protected Routes Reject Unauthenticated / Unauthorized Requests

## Test Method

Reviewed authentication and authorization exception handling.

Command:

```powershell
findstr /n /i "UnauthorizedException ForbiddenException" src\common\auth.ts
```

## Evidence Found

Location:

```
src/common/auth.ts
```

Evidence:

```ts
if (!header?.startsWith("Bearer "))
    throw new UnauthorizedException("Missing token");


if (!user)
    throw new UnauthorizedException("Invalid or expired token");


throw new ForbiddenException("Role not permitted");


throw new ForbiddenException(`Missing permission: ${perm}`);


if (!req.claims)
    throw new UnauthorizedException();
```

---

## Verification

The backend rejects:

### Missing Token

Example:

```
No Authorization header
        ↓
401 Unauthorized
```

---

### Invalid / Expired Token

Example:

```
Invalid JWT
        ↓
401 Unauthorized
```

---

### Incorrect Role

Example:

```
User role does not match required role
        ↓
403 Forbidden
```

---

### Missing Permission

Example:

```
Required permission unavailable
        ↓
403 Forbidden
```

---

## Status

✅ PASS

---

# Authorization Testing Final Result

| Test Case | Status | Evidence |
| --- | --- | --- |
| Admin-only APIs blocked for non-admin users | ✅ PASS | `@Roles()` restrictions |
| Role-based access control enforced in code | ✅ PASS | `RolesGuard` implementation |
| Permission checks enforced at each protected action | ✅ PASS | `@RequirePerm()` decorators |
| Protected routes reject unauthorized requests | ✅ PASS | UnauthorizedException / ForbiddenException |

---

# Overall Section Result

## ✅ AUTHORIZATION TESTING — PASS

### Summary

The VOC-AMC backend implements a layered authorization model using:

- JWT authentication guard

- Role-based access control

- Permission-based authorization

- Controller-level security decorators

- Exception handling for unauthorized access

No authorization weaknesses were identified during static security review.

---

**Evidence Collected:**

- Controller role restrictions

- Permission decorators

- Authorization guards

- Authentication exception handling

- Role and permission validation logic